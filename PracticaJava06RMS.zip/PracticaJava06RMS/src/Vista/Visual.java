
package Vista;

//Import necesarios//

import Controlador.ArchivoError;
import Modelo.Cliente;
import Modelo.Vendedor;
import javax.swing.JMenu;
import javax.swing.JOptionPane;

/**
 *
 * @author Rafae
 */
public class Visual extends javax.swing.JFrame {
    
    //Creamos los atributos necesarios//
    
    Cliente cli;
    PeliculaVista pelis = new PeliculaVista();
    VendedorVista ven = new VendedorVista();
    ConexionVista conex;
    ClienteVista vist;
    Vendedor vende;
    AlquilerPeliVista alquiVist;
   
    /**
     * Creates new form Visual
     */
    
    public Visual() {
        initComponents();
        datosMenu.setEnabled(false);
        ArchivoError archErr = new ArchivoError();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        conexionMenu = new javax.swing.JMenu();
        datosMenu = new javax.swing.JMenu();
        peliculasMenuItem = new javax.swing.JMenuItem();
        clienteMenuItem = new javax.swing.JMenuItem();
        vendedorMenuItem = new javax.swing.JMenuItem();
        detalleMenu = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenu1 = new javax.swing.JMenu();

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/videoclu1.jpg"))); // NOI18N
        jLabel3.setText(" ");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(0, 0));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/videoclu1.jpg"))); // NOI18N
        jLabel1.setText("  ");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 428, 370));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 430, 390));

        conexionMenu.setText("Conectarse");
        conexionMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                conexionMenuMouseClicked(evt);
            }
        });
        jMenuBar1.add(conexionMenu);

        datosMenu.setText("Datos");

        peliculasMenuItem.setText("Peliculas");
        peliculasMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                peliculasMenuItemActionPerformed(evt);
            }
        });
        datosMenu.add(peliculasMenuItem);

        clienteMenuItem.setText("Cliente");
        clienteMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clienteMenuItemActionPerformed(evt);
            }
        });
        datosMenu.add(clienteMenuItem);

        vendedorMenuItem.setText("Vendedores");
        vendedorMenuItem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                vendedorMenuItemMouseClicked(evt);
            }
        });
        vendedorMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vendedorMenuItemActionPerformed(evt);
            }
        });
        datosMenu.add(vendedorMenuItem);

        detalleMenu.setText("Detalle Alquiler");
        detalleMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                detalleMenuMouseClicked(evt);
            }
        });
        detalleMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                detalleMenuActionPerformed(evt);
            }
        });
        datosMenu.add(detalleMenu);

        jMenuBar1.add(datosMenu);

        jMenu2.setText("AcercaDe");
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu2);

        jMenu1.setIcon(new javax.swing.ImageIcon("/home/alumno/Escritorio/x.png")); // NOI18N
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void peliculasMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_peliculasMenuItemActionPerformed
        cambiarPanel(pelis);
    }//GEN-LAST:event_peliculasMenuItemActionPerformed

    private void conexionMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_conexionMenuMouseClicked
        conex = new ConexionVista(this);
        cambiarPanel(conex);
    }//GEN-LAST:event_conexionMenuMouseClicked

    private void clienteMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clienteMenuItemActionPerformed
       vist = new ClienteVista(cli,this);
       cambiarPanel(vist);
    }//GEN-LAST:event_clienteMenuItemActionPerformed

    private void vendedorMenuItemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vendedorMenuItemMouseClicked
       cambiarPanel(ven);
    }//GEN-LAST:event_vendedorMenuItemMouseClicked

    private void vendedorMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vendedorMenuItemActionPerformed
        cambiarPanel(ven);
    }//GEN-LAST:event_vendedorMenuItemActionPerformed

    private void detalleMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_detalleMenuMouseClicked
 
    }//GEN-LAST:event_detalleMenuMouseClicked

    private void detalleMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_detalleMenuActionPerformed
        alquiVist = new AlquilerPeliVista(cli,this);
        cambiarPanel(alquiVist);
    }//GEN-LAST:event_detalleMenuActionPerformed

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
        
        //Mostramos un panel de confirmacion y salimos//
        if( JOptionPane.showConfirmDialog(this,"Realmente Desea salir?","Salir" ,JOptionPane.OK_CANCEL_OPTION,JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION){
             this.dispose(); 
        }else{
          
            JOptionPane.showMessageDialog(this, "Gracias por quedarte", "Bienvenido de nuevo", HEIGHT);
        }
      
    }//GEN-LAST:event_jMenu1MouseClicked

    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu2MouseClicked
        AcercaDe dialog = new AcercaDe(new java.awt.Frame(), true);
        dialog.setLocationRelativeTo(this);
        dialog.setTitle("Nueva Factura");
        dialog.setVisible(true);
    }//GEN-LAST:event_jMenu2MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Visual.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Visual.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Visual.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Visual.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               Visual frame = new Visual();
                    frame.setVisible(true);
                    frame.setLocationRelativeTo(null);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem clienteMenuItem;
    private javax.swing.JMenu conexionMenu;
    private javax.swing.JMenu datosMenu;
    private javax.swing.JMenuItem detalleMenu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JMenuItem peliculasMenuItem;
    private javax.swing.JMenuItem vendedorMenuItem;
    // End of variables declaration//GEN-END:variables

    //Cambiar el panel//
    
    private void cambiarPanel(javax.swing.JPanel aux){
        this.setContentPane(aux);
        pack();
    }  
    
    public  void setDatosMenu(JMenu datosMenu) {
        this.datosMenu = datosMenu;
    }

    public JMenu getDatosMenu() {
        return datosMenu;
    }
}
