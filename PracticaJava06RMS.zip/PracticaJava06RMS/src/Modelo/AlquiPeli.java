
package Modelo;

import Controlador.Herramienta;
import java.util.GregorianCalendar;

/**
 *
 * @author Rafae
 */
public class AlquiPeli {
    
    //Creamos las variables//
    
    private int codpeli;
    private int codalqui;
    private float precio;
    private GregorianCalendar fecha;
    private int cantidad;
    
    //Constructor//
    
    public AlquiPeli(int codpeli, int codalqui, float precio, GregorianCalendar fecha, int cantidad) {
        this.codpeli = codpeli;
        this.codalqui = codalqui;
        this.precio = precio;
        this.fecha = fecha;
        this.cantidad = cantidad;
    }
    
    //Getter y Setter//

    public int getCodpeli() {
        return codpeli;
    }

    public void setCodpeli(int codpeli) {
        this.codpeli = codpeli;
    }

    public int getCodalqui() {
        return codalqui;
    }

    public void setCodalqui(int codalqui) {
        this.codalqui = codalqui;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public GregorianCalendar getFecha() {
        return fecha;
    }

    public void setFecha(GregorianCalendar fecha) {
        this.fecha = fecha;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        return "\n Codigo Pelicula: " + codpeli + " \nCodigo alquiler:  " + codalqui +
                " \nPrecio:  " + precio + "\n Fecha venta:  " + Herramienta.gregorianCalendarToString(fecha)+ "  \nCantidad:  " + cantidad;
    }
    
    
}
