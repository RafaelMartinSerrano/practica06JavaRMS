

package Modelo;
import Controlador.Herramienta;
import java.util.GregorianCalendar;

/**
 *
 * @author Rafae
 */
public class Vendedor {
    //Creamos las variables//
    private int codigoven;
    private String nombre;
    private String foto;
    private GregorianCalendar fechaAlta;
    private int jefe;

    //Constructores//
    
    public Vendedor(int codigoven, String nombre, String foto, GregorianCalendar fechaAlta, int jefe) {
        this.codigoven = codigoven;
        this.nombre = nombre;
        this.foto = foto;
        this.fechaAlta = fechaAlta;
        this.jefe = jefe;
    }
    
    
    //Getter y Setter//
    public int getCodigoven() {
        return codigoven;
    }

    public void setCodigoven(int codigoven) {
        this.codigoven = codigoven;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public GregorianCalendar getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(GregorianCalendar fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public int getJefe() {
        return jefe;
    }

    public void setJefe(int jefe) {
        this.jefe = jefe;
    }

    @Override
    public String toString() {
        return "\nVendedor:" + "\nCodigo: " + codigoven + "\nNombre: "
                + nombre + "\nFoto: " + foto + "\nFecha Alta: "
                +Herramienta.gregorianCalendarToString(fechaAlta)  + "\nJefe: " + jefe;
    }
    
    
}
