
package Modelo;

import Controlador.Herramienta;
import java.util.GregorianCalendar;

/**
 *
 * @author Rafae
 */
public class Alquiler {
    
    //Creamos las variables necesarias//
    
    private int codigoalqui;
    private float total;
    private float maximo;
    private GregorianCalendar fecha;
    private int codCliente;
    private int codVendedor;

    //Constructor//
    
    public Alquiler(int codigoalqui, float total, float maximo, GregorianCalendar fecha, int codCliente, int codVendedor) {
        this.codigoalqui = codigoalqui;
        this.total = total;
        this.maximo = maximo;
        this.fecha = fecha;
        this.codCliente = codCliente;
        this.codVendedor = codVendedor;
    }

    //Getter y Setter//
    
    public int getCodigoalqui() {
        return codigoalqui;
    }

    public void setCodigoalqui(int codigoalqui) {
        this.codigoalqui = codigoalqui;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public float getMaximo() {
        return maximo;
    }

    public void setMaximo(float maximo) {
        this.maximo = maximo;
    }

    public GregorianCalendar getFecha() {
        return fecha;
    }

    public void setFecha(GregorianCalendar fecha) {
        this.fecha = fecha;
    }

    public int getCodCliente() {
        return codCliente;
    }

    public void setCodCliente(int codCliente) {
        this.codCliente = codCliente;
    }

    public int getCodVendedor() {
        return codVendedor;
    }

    public void setCodVendedor(int codVendedor) {
        this.codVendedor = codVendedor;
    }

    @Override
    public String toString() {
        return "\nAlquiler: " + "\nCodigo: " + codigoalqui + "\nTotal: " + total + "\nMaximo:" + maximo
                + "\nFecha: " + Herramienta.gregorianCalendarToString(fecha) + "\nCliente: " + codCliente
                 + "\nVendedor: " + codVendedor;
    }
       
}
