
package Modelo;

/**
 *
 * @author Rafae
 */
public class Pelicula {
    
    //Creamos las variables//
    private int codigopelicula;
    private String nombrepelicula;
    private String tipo;
    private float precio;
    private String foto;

    //Constructor//
    public Pelicula(int codigopelicula, String nombrepelicula, String tipo, float precio, String foto) {
        this.codigopelicula = codigopelicula;
        this.nombrepelicula = nombrepelicula;
        this.tipo = tipo;
        this.precio = precio;
        this.foto = foto;
    }
    
    //Getter y Setter//
    public int getCodigopelicula() {
        return codigopelicula;
    }

    public void setCodigopelicula(int codigopelicula) {
        this.codigopelicula = codigopelicula;
    }

    public String getNombrepelicula() {
        return nombrepelicula;
    }

    public void setNombrepelicula(String nombrepelicula) {
        this.nombrepelicula = nombrepelicula;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }
    
    //Metodo to-string//

    @Override
    public String toString() {
        return "\nPelicula: " + "\nCodigo: " + codigopelicula + "\nNombre: " + nombrepelicula 
                            + "\nTipo: " + tipo + "\nPrecio: " + precio + "\nFoto: " + foto;
    }
    
    
}
