
package Modelo;

import Controlador.Herramienta;
import java.util.GregorianCalendar;

/**
 *
 * @author Rafae
 */
public class Cliente {
    
    //Creamos las variables de cliente//
    private int codigocli;
    private String nombre;
    private String contraseña;
    private float saldo;
    private GregorianCalendar fecha;
    private String nif;
    private String foto;
    private float totalalqui;
    //Constructores//

    public Cliente(int codigocli, String nombre, String contraseña, float saldo, GregorianCalendar fecha, String nif, String foto,float total) {
        this.codigocli = codigocli;
        this.nombre = nombre;
        this.contraseña = contraseña;
        this.saldo = saldo;
        this.fecha = fecha;
        this.nif = nif;
        this.foto = foto;
        this.totalalqui = total;
    }
    
   

    //Getter y Setter//
    public float getTotalalqui() {
        return totalalqui;
    }
    public void setTotalalqui(float totalalqui) {    
        this.totalalqui = totalalqui;
    }

    public int getCodigocli() {
        return codigocli;
    }

    public void setCodigocli(int codigocli) {
        this.codigocli = codigocli;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public GregorianCalendar getFecha() {
        return fecha;
    }

    public void setFecha(GregorianCalendar fecha) {
        this.fecha = fecha;
    }

    public String getNif() {
        return nif;
    }

    public void setNif(String nif) {
        this.nif = nif;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    @Override
    public String toString() {
        return "\nCliente: " + "\nCodigo: " + codigocli + "\nNombre: " + nombre 
                           +"\nSaldo: " + saldo + "\nFecha Nacimiento:" + Herramienta.gregorianCalendarToString(fecha) 
                            + "\nNif: " + nif + "\nFoto: " + foto;
    }
    
    
}
