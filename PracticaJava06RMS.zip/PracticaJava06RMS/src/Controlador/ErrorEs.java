package Controlador;

public class ErrorEs extends Exception{
    private int codigoError;
    
    public ErrorEs(int codigoError){
        this.codigoError = codigoError;
    }

    public int getCodigoError(){
        return codigoError;
    }
    
    @Override
    public String getMessage(){
        //Hacemos override al getMessage que tienen todas las exception para tratar todos los catch igual//
        String salida;
        switch(this.codigoError){
            
            case 1 :
                salida = "CODIGO ERROR: 1 MENSAJE ERROR: USUARIO NO VALIDO ";
                break;
            case 2 :
                salida = "CODIGO ERROR: 2 MENSAJE ERROR: FECHA INVALIDA";
                break;       
            case 3 :
                salida = "CODIGO ERROR: 3 MENSAJE ERROR: CANTIDAD INVALIDA";
                break;       
            case 4 :
                salida = "CODIGO ERROR: 4 MENSAJE ERROR: IMAGEN NO CAMBIADA ";
                break;
            case 5 :
                salida = "CODIGO ERROR: 5 MENSAJE ERROR: MAXIMO SUPERADO ";
                break; 
            case 6 :
                salida = "CODIGO ERROR: 6 MENSAJE ERROR: CANTIDAD EN BLANCO ";
                break;
            case 7 :
                salida = "CODIGO ERROR: 7 MENSAJE ERROR: DNI NO VALIDO ";
                break;     
            case 8 :
                salida = "CODIGO ERROR: 8 MENSAJE ERROR: SALDO NO PUEDE BAJAR DE 0 ";
                break; 
            case 9 :
                salida = "CODIGO ERROR: 9 MENSAJE ERROR: ERROR EN BASE DE DATO ";
                break;  
            default:
                
                salida = "ERROR SIN DOCUMENTAR";
                break;
        }
        return salida;
    }
}

    
  

