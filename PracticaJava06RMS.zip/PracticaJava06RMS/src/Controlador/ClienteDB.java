
package Controlador;

import Modelo.Cliente;
import java.sql.*;
import java.util.ArrayList;


public class ClienteDB {
    
    private static int correcto = 0;
    private static Statement st = null;
    private static ResultSet rs = null;
    
   public static int getcorrecto() {
        return correcto;
    }
   
   public static void setcorrecto(int correc)
   {
       ClienteDB.correcto = correc;
   }
   
    public static void actualizarClien(String query){
       
        
        try{
            st = ConexionDB.getConnection().createStatement();
            int rs = st.executeUpdate(query);
            
            st.close();
            
        }catch(SQLException e){
            System.out.println("Error consulta actualizar cliente" + e);
      
        }        
        
    }
    
    public static void cambiarFoto(String aux,int cliente){
       
        String query = "UPDATE  CLIENTE SET FOTO = '" + aux + "' WHERE CODIGOCLI =" + cliente;
        try{
            st = ConexionDB.getConnection().createStatement();
            int rs = st.executeUpdate(query);
            
            st.close();
            
        }catch(SQLException e){
            System.out.println("Error consulta cambiar foto cliente" + e);
      
        }        
        
    }
       
        
   
    public static ArrayList getClientes(String query){
        ArrayList<Cliente> lista = new ArrayList<>();
        try{
            st = ConexionDB.getConnection().createStatement();
            rs = st.executeQuery(query);
            while(rs.next()){
                       
                Cliente auxEmp = new Cliente(rs.getInt(1),
                                            rs.getString(2),
                                            rs.getString(3),
                                            rs.getFloat(4),
                                            Herramienta.dateToGregorianCalendar(rs.getDate(5)),
                                            rs.getString(6),
                                            rs.getString(7),
                                            rs.getInt(8));
                
                lista.add(auxEmp);
               
            }
            rs.close();
            st.close();
            
        }catch(SQLException e){
            System.out.println("Error consulta lista cliente" + e);
          
        }        
        return lista;
    }
    public static Cliente getPrepareStatement(String nom,String contra){
        
        Cliente cli = null;
        
        try{
            String query = "SELECT * FROM CLIENTE WHERE NOMBRE = ? AND CONTRASE = ?"; 
            PreparedStatement myStmt;
            myStmt = ConexionDB.getConnection().prepareStatement(query);
            myStmt.setString(1,nom);
            myStmt.setString(2,contra);
            ResultSet rs= myStmt.executeQuery();  
            while(rs.next()){
                       
                cli = new Cliente(  rs.getInt(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    rs.getFloat(4),
                                    Herramienta.dateToGregorianCalendar(rs.getDate(5)),
                                    rs.getString(6),
                                    rs.getString(7),
                                    rs.getInt(8)
                );
            }
            myStmt.close();
            rs.close();
            
        }catch(SQLException e){
            System.out.println("Error consulta cliente" + e);
      
        }        
        return cli;
    }
    
     public static Cliente getCliente(String query){
        
        Cliente cli = null;
        
        try{
            st = ConexionDB.getConnection().createStatement();
            rs = st.executeQuery(query);
         
            while(rs.next()){
                       
                cli = new Cliente(  rs.getInt(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    rs.getFloat(4),
                                    Herramienta.dateToGregorianCalendar(rs.getDate(5)),
                                    rs.getString(6),
                                    rs.getString(7),
                                    rs.getInt(8)
                );
            }
            rs.close();
            st.close();
            
        }catch(SQLException e){
            System.out.println("Error consulta cliente" + e);
      
        }        
        return cli;
    }
}   
