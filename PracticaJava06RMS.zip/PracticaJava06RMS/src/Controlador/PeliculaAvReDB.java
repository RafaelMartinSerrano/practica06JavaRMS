/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;



import Modelo.Pelicula;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import Modelo.Pelicula;

import Modelo.Pelicula;


public class PeliculaAvReDB {
    private static Statement st = null;
    private static ResultSet rs = null;

    public static ResultSet getRs() {
        return rs;
    }

    public static void setRs(ResultSet rs) {
        PeliculaAvReDB.rs = rs;
    }
    
    public static Pelicula Actualizar(String query){
        Pelicula peli = null;
        
        try{
            st = ConexionDB.getConnection().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            st.executeUpdate(query);
         
                       
                peli = new Pelicula(rs.getInt(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    rs.getInt(4),
                                    rs.getString(5));
            
 
            
        }catch(SQLException e){
            System.out.println("Error actualizar pelicula" + e);
            System.out.println(e);
      
        }        
        return peli;
    }
    
    public static Pelicula getPeli(String query){
        
        Pelicula peli = null;
        
        try{
            st = ConexionDB.getConnection().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = st.executeQuery(query);
         
            rs.next();
                       
                peli = new Pelicula(rs.getInt(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    rs.getInt(4),
                                    rs.getString(5));
            
 
            
        }catch(SQLException e){
            System.out.println("Error consulta pelicula" + e);
            System.out.println(e);
      
        }        
        return peli;
    }
    
    public static Pelicula atras(){
        
        Pelicula peli = null;
        try {
            rs.previous();
           
            peli = new Pelicula(rs.getInt(1),
                                rs.getString(2),
                                rs.getString(3),
                                rs.getInt(4),
                                rs.getString(5));
            
        } catch (SQLException ex) {
            Logger.getLogger(Pelicula.class.getName()).log(Level.SEVERE, null, ex);
        }
        return peli;
    }
    
    public static Pelicula alante(){
        Pelicula peli = null;
       
        try {
            rs.next();
                       
                peli = new Pelicula(rs.getInt(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    rs.getInt(4),
                                    rs.getString(5));
        } catch (SQLException ex) {
            Logger.getLogger(Pelicula.class.getName()).log(Level.SEVERE, null, ex);
        }
         return peli;
    }
   public static Pelicula primero(){
        
        Pelicula peli = null;
        try {
            rs.first();
           
            peli = new Pelicula(rs.getInt(1),
                                rs.getString(2),
                                rs.getString(3),
                                rs.getInt(4),
                                rs.getString(5));
            
        } catch (SQLException ex) {
            Logger.getLogger(Pelicula.class.getName()).log(Level.SEVERE, null, ex);
        }
        return peli;
    }
   public static Pelicula ultimo(){
        
        Pelicula peli = null;
        try {
            rs.last();
           
            peli = new Pelicula(rs.getInt(1),
                                rs.getString(2),
                                rs.getString(3),
                                rs.getInt(4),
                                rs.getString(5));
            
        } catch (SQLException ex) {
            Logger.getLogger(Pelicula.class.getName()).log(Level.SEVERE, null, ex);
        }
        return peli;
    }
}