
package Controlador;



import Modelo.AlquiPeli;
import Modelo.Alquiler;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


import Modelo.Pelicula;
import java.util.ArrayList;


public class AlquilerAvReDB {
    private static Statement st = null;
    private static ResultSet rs = null;

    public static ResultSet getRs() {
        return rs;
    }

    public static void setRs(ResultSet rs) {
        AlquilerAvReDB.rs = rs;
    }
    
    
     public static ArrayList getAlquiPeli(String query){
        ArrayList<AlquiPeli> lista = new ArrayList<>();
        try{
            st = ConexionDB.getConnection().createStatement();
            rs = st.executeQuery(query);
            while(rs.next()){
                       
                AlquiPeli auxAlquiPeli = new AlquiPeli(rs.getInt(1),
                                                        rs.getInt(2),
                                                        rs.getFloat(3),
                                                        Herramienta.dateToGregorianCalendar(rs.getDate(4)),
                                                        rs.getInt(5));
                
                lista.add(auxAlquiPeli);
               
            }
            
            
        }catch(SQLException e){
            System.out.println("Error consulta lista alquiler peliculas" + e);
          
        }        
        return lista;
    }
    
    public static void Actualizar(String query){
        
      
        try{
            st = ConexionDB.getConnection().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            st.executeUpdate(query);
                     
        }catch(SQLException e){
            System.out.println("Error actualizar Alquiler" + e);
            System.out.println(e);
      
        }        
    
    }
    
    public static Alquiler getAlquiler(String query){
        
        Alquiler alqui = null;
        
        try{
            st = ConexionDB.getConnection().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = st.executeQuery(query);
         
            rs.next();
                       
                alqui = new Alquiler(rs.getInt(1),
                                    rs.getFloat(2),
                                    rs.getFloat(3),
                                    Herramienta.dateToGregorianCalendar(rs.getDate(4)),
                                    rs.getInt(5),
                                    rs.getInt(6));
            
 
            
        }catch(SQLException e){
            System.out.println("Error consulta Alquiler" + e);
            System.out.println(e);
      
        }        
        return alqui;
    }
    
    public static Alquiler atras(){
        
        Alquiler alqui = null;
        try {
            rs.previous();
           
            alqui = new Alquiler(rs.getInt(1),
                                rs.getFloat(2),
                                rs.getFloat(3),
                                Herramienta.dateToGregorianCalendar(rs.getDate(4)),
                                rs.getInt(5),
                                rs.getInt(6));
            
        } catch (SQLException ex) {
            Logger.getLogger(Pelicula.class.getName()).log(Level.SEVERE, null, ex);
        }
        return alqui;
    }
    
    public static Alquiler alante(){
        Alquiler alqui = null;
       
        try {
            rs.next();
                       
                alqui = new Alquiler(rs.getInt(1),
                                    rs.getFloat(2),
                                    rs.getFloat(3),
                                    Herramienta.dateToGregorianCalendar(rs.getDate(4)),
                                    rs.getInt(5),
                                    rs.getInt(6));

        } catch (SQLException ex) {
            Logger.getLogger(Pelicula.class.getName()).log(Level.SEVERE, null, ex);
        }
         return alqui;
    }
   public static Alquiler primero(){
        
        Alquiler alqui = null;
        try {
            rs.first();
           
            alqui = new Alquiler(rs.getInt(1),
                                rs.getFloat(2),
                                rs.getFloat(3),
                                Herramienta.dateToGregorianCalendar(rs.getDate(4)),
                                rs.getInt(5),
                                rs.getInt(6));
            
        } catch (SQLException ex) {
            Logger.getLogger(Pelicula.class.getName()).log(Level.SEVERE, null, ex);
        }
        return alqui;
    }
   public static Alquiler ultimo(){
        
        Alquiler alqui = null;
        try {
            rs.last();
           
            alqui = new Alquiler(rs.getInt(1),
                                rs.getFloat(2),
                                rs.getFloat(3),
                                Herramienta.dateToGregorianCalendar(rs.getDate(4)),
                                rs.getInt(5),
                                rs.getInt(6));
            
        } catch (SQLException ex) {
            Logger.getLogger(Pelicula.class.getName()).log(Level.SEVERE, null, ex);
        }
        return alqui;
    }
}