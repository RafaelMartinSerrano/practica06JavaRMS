
package Controlador;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ArchivoError {
    static final String PATH = "/home/alumno/Escritorio/PracticaJava06RMS/errores.txt";
    private static File fichero;
      
    public ArchivoError(){
        try {
            //Creamos el fichero de errores//
            fichero = new File(PATH);
            fichero.createNewFile();
        } catch (IOException ex) {
            Logger.getLogger(ArchivoError.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //Formato para los errorres
    private static String formatoError(String error){
        String aux;
        
        //Recogemos el momento del error//
        Timestamp ts = new Timestamp(System.currentTimeMillis());
        aux = "\nFECHA: " + ts.toString() + " ";
        
        //Añadimos el mensaje de error//
        aux += error;
        
        return aux;
    }
    
    //Escribimos una nueva linea en el archivo de errores
    public static void nuevaLinea(String error){
        try {
          
            //Abrimos el buffered writer//
            BufferedWriter escritura = new BufferedWriter(new FileWriter(fichero, true));
            
            //Escribimos el error//
            escritura.write(formatoError(error));
            
            //Cerramos//
            escritura.close();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ArchivoError.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}