/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;




import Modelo.Pelicula;
import Modelo.Vendedor;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


public class VendedorDB {
    private static Statement st = null;
    private static ResultSet rs = null;

    public static ResultSet getRs() {
        return rs;
    }

    public static void setRs(ResultSet rs) {
        VendedorDB.rs = rs;
    }
    
    public static Vendedor Actualizar(String query){
        Vendedor vendi = null;
        
        try{
            st = ConexionDB.getConnection().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            st.executeUpdate(query);
         
                       
                vendi = new Vendedor(rs.getInt(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    Herramienta.dateToGregorianCalendar(rs.getDate(4)),
                                    rs.getInt(5));
            
 
            
        }catch(SQLException e){
            System.out.println("Error actualizar Vendedor" + e);
            System.out.println(e);
      
        }        
        return vendi;
    }
    
    public static Vendedor getVendedor(String query){
        
        Vendedor vendi = null;
        
        try{
            st = ConexionDB.getConnection().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = st.executeQuery(query);
         
            rs.next();
                       
                vendi = new Vendedor(rs.getInt(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    Herramienta.dateToGregorianCalendar(rs.getDate(4)),
                                    rs.getInt(5));
            
 
            
        }catch(SQLException e){
            System.out.println("Error consulta Vendedor" + e);
            System.out.println(e);
      
        }        
        return vendi;
    }
    
    public static Vendedor atras(){
        
        Vendedor vendi = null;
        try {
            rs.previous();
           
            vendi = new Vendedor(rs.getInt(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    Herramienta.dateToGregorianCalendar(rs.getDate(4)),
                                    rs.getInt(5));
            
        } catch (SQLException ex) {
            Logger.getLogger(Pelicula.class.getName()).log(Level.SEVERE, null, ex);
        }
        return vendi;
    }
    
    public static Vendedor alante(){
        Vendedor vendi = null;
       
        try {
            rs.next();
                       
                vendi = new Vendedor(rs.getInt(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    Herramienta.dateToGregorianCalendar(rs.getDate(4)),
                                    rs.getInt(5));
        } catch (SQLException ex) {
            Logger.getLogger(Pelicula.class.getName()).log(Level.SEVERE, null, ex);
        }
         return vendi;
    }
   public static Vendedor primero(){
        
        Vendedor vendi = null;
        try {
            rs.first();
           
            vendi = new Vendedor(rs.getInt(1),
                                rs.getString(2),
                                rs.getString(3),
                                Herramienta.dateToGregorianCalendar(rs.getDate(4)),
                                rs.getInt(5));
            
        } catch (SQLException ex) {
            Logger.getLogger(Pelicula.class.getName()).log(Level.SEVERE, null, ex);
        }
        return vendi;
    }
   public static Vendedor ultimo(){
        
        Vendedor vendi = null;
        try {
            rs.last();
           
            vendi = new Vendedor(rs.getInt(1),
                                rs.getString(2),
                                rs.getString(3),
                                Herramienta.dateToGregorianCalendar(rs.getDate(4)),
                                rs.getInt(5));
            
        } catch (SQLException ex) {
            Logger.getLogger(Pelicula.class.getName()).log(Level.SEVERE, null, ex);
        }
        return vendi;
    }
}