/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;


import java.sql.*;

public class ConexionDB {

    private static Connection con = null;

    public static void open() {
        try {
            Class.forName("org.gjt.mm.mysql.Driver");	
        } catch (ClassNotFoundException e) {
            System.out.println("ERROR: exception loading driver class");
        }
               
        String url = "jdbc:mysql://localhost:4200/VIDEOCLUB";
        try {
            con = DriverManager.getConnection(url,"root","1234");
        } catch (SQLException ex) {
            System.out.println("ERROR: conexion");
        }
        
    }


    public static Connection getConnection() throws SQLException {
        return con;
    } 
    
    public static void close() {
        try {
            con.close();
        } catch (Exception ignored) {}
    } 
}