
package Controlador;

import Modelo.AlquiPeli;
import Modelo.Alquiler;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 *
 * @author Rafae
 */
public class AlquiPeliDB {
    private static int correcto = 0;
    private static Statement st = null;
    private static ResultSet rs = null;
    
   public static int getcorrecto() {
        return correcto;
    }
   
   public static void setcorrecto(int correc)
   {
       AlquiPeliDB.correcto = correc;
   }
   
   
   public static void eliminarAlquiPeli(int codpeli,int codal){
       
        String query = "DELETE FROM ALQUIPELI WHERE CODPELI= " + codpeli+" AND CODALQUI= " + codal;
        
        try{
            st = ConexionDB.getConnection().createStatement();
            int rs = st.executeUpdate(query);
           
            st.close();
            
        }catch(SQLException e){
            System.out.println("Error consulta eliminar alquiler pelicula " + e);
      
        }        
      
    }
   
    public static void actualizarAlquiPeli(int codpeli,int codal,float prec,String dia,int cantidad){
       
        String query = "INSERT INTO ALQUIPELI VALUES("+ codpeli+"," + codal+"," + prec+",'" + dia+"' ," + cantidad + ")";
        
        try{
            st = ConexionDB.getConnection().createStatement();
            int rs = st.executeUpdate(query);
            
            st.close();
            
        }catch(SQLException e){
            System.out.println("Error consulta actualizar alquiler pelicula " + e);
      
        }        
      
    }
       
        
   
    public static ArrayList getAlquiPeli(String query){
        ArrayList<AlquiPeli> lista = new ArrayList<>();
        try{
            st = ConexionDB.getConnection().createStatement();
            rs = st.executeQuery(query);
            while(rs.next()){
                       
                AlquiPeli auxAlquiPeli = new AlquiPeli(rs.getInt(1),
                                                        rs.getInt(2),
                                                        rs.getFloat(3),
                                                        Herramienta.dateToGregorianCalendar(rs.getDate(4)),
                                                        rs.getInt(5));
                
                lista.add(auxAlquiPeli);
               
            }
            rs.close();
            st.close();
            
        }catch(SQLException e){
            System.out.println("Error consulta lista alquiler peliculas" + e);
          
        }        
        return lista;
    }
    
     public static AlquiPeli getAlquiler(String query){
        
        AlquiPeli alpe = null;
        
        try{
            st = ConexionDB.getConnection().createStatement();
            rs = st.executeQuery(query);
         
            while(rs.next()){
                       
                alpe = new AlquiPeli(rs.getInt(1),
                                    rs.getInt(2),
                                    rs.getFloat(3),
                                    Herramienta.dateToGregorianCalendar(rs.getDate(4)),
                                    rs.getInt(5));
            }
            rs.close();
            st.close();
            
        }catch(SQLException e){
            System.out.println("Error consulta alquiler" + e);
      
        }        
        return alpe;
    }
}   

