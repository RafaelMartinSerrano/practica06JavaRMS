/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Alquiler;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Rafae
 */
public class AlquilerDB {
   
    private static int correcto = 0;
    private static Statement st = null;
    private static ResultSet rs = null;
    
   public static int getcorrecto() {
        return correcto;
    }
   
   public static void setcorrecto(int correc)
   {
       AlquilerDB.correcto = correc;
   }
   
    public static void actualizarAlquiler(String query){
        
        try{
            st = ConexionDB.getConnection().createStatement();
            int rs = st.executeUpdate(query);
            
            st.close();
            
        }catch(SQLException e){
            System.out.println("Error consulta actualizar alquiler"+ e);
      
        }        
     
    }
       
        
   
    public static ArrayList getAlquileres(String query){
        ArrayList<Alquiler> lista = new ArrayList<>();
        try{
            st = ConexionDB.getConnection().createStatement();
            rs = st.executeQuery(query);
            while(rs.next()){
                       
                Alquiler auxAlqui = new Alquiler(rs.getInt(1),
                                                rs.getFloat(2),
                                                rs.getFloat(3),
                                                Herramienta.dateToGregorianCalendar(rs.getDate(4)),
                                                rs.getInt(5),
                                                rs.getInt(6));
                
                lista.add(auxAlqui);
               
            }
            rs.close();
            st.close();
            
        }catch(SQLException e){
            System.out.println("Error consulta lista alquiler" + e);
          
        }        
        return lista;
    }
    
     public static Alquiler getAlquiler(String query){
        
        Alquiler al = null;
        
        try{
            st = ConexionDB.getConnection().createStatement();
            rs = st.executeQuery(query);
         
            while(rs.next()){
                       
                al = new Alquiler(  rs.getInt(1),
                                    rs.getFloat(2),
                                    rs.getFloat(3),
                                    Herramienta.dateToGregorianCalendar(rs.getDate(4)),
                                    rs.getInt(5),
                                    rs.getInt(6));
            }
            rs.close();
            st.close();
            
        }catch(SQLException e){
            System.out.println("Error consulta alquiler" + e);
      
        }        
        return al;
    }
}   
