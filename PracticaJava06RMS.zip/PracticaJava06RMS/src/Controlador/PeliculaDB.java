
package Controlador;

import Modelo.Pelicula;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Rafae
 */
public class PeliculaDB {
    private static int correcto = 0;
    private static Statement st = null;
    private static ResultSet rs = null;
    
   public static int getcorrecto() {
        return correcto;
    }
   
   public static void setcorrecto(int correc)
   {
       PeliculaDB.correcto = correc;
   }
   
    public static Pelicula actualizarPelicula(String query){
       
         Pelicula peli = null;
        
        try{
            st = ConexionDB.getConnection().createStatement();
            int rs = st.executeUpdate(query);
            
            st.close();
            
        }catch(SQLException e){
            System.out.println("Error consulta actualizar pelicula" + e);
      
        }        
        return peli;
    }
       
        
   
    public static ArrayList getPeliculas(String query){
        ArrayList<Pelicula> lista = new ArrayList<>();
        try{
            st = ConexionDB.getConnection().createStatement();
            rs = st.executeQuery(query);
            while(rs.next()){
                       
                Pelicula auxPeli = new Pelicula(rs.getInt(1),
                                                rs.getString(2),
                                                rs.getString(3),
                                                rs.getInt(4),
                                                rs.getString(5));
                
                lista.add(auxPeli);
               
            }
            rs.close();
            st.close();
            
        }catch(SQLException e){
            System.out.println("Error consulta lista pelicula" + e);
          
        }        
        return lista;
    }
    
     public static Pelicula getPelicula(String query){
        
        Pelicula peli = null;
        
        try{
            st = ConexionDB.getConnection().createStatement();
            rs = st.executeQuery(query);
         
            while(rs.next()){
                       
                peli = new Pelicula( rs.getInt(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    rs.getFloat(4),
                                    rs.getString(5));
            }
            rs.close();
            st.close();
            
        }catch(SQLException e){
            System.out.println("Error consulta pelicula" + e);
      
        }        
        return peli;
    } 
}
