
package Controlador;

import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class Herramienta { 
  
    public static String gregorianCalendarToString(GregorianCalendar fecha){         
        SimpleDateFormat formatDate = new SimpleDateFormat("dd/MM/yyyy");
        return formatDate.format(fecha.getTime());        
    }    
    //
    public static GregorianCalendar dateToGregorianCalendar(Date fecha){
        GregorianCalendar gc = new GregorianCalendar();
        gc.setTime(fecha);
        return gc;
    }
    
    //copiar fichero a nuestra carpeta//
    
    public static void fichCop(File origen, File destino){
        FileInputStream lec = null;
        try {
            
            String ruCop = destino.getAbsolutePath();
            if(System.getProperty("os.name").equals("Linux")){
                ruCop = ruCop + "/" + origen.getName();
                
            }
            else{
                ruCop = ruCop + "\\" + origen.getName();
            }
            
            //Creamos el destino//
            File copia = new File(ruCop);
            
            copia.createNewFile();
          
            
            
            //Leemos y escribimos//
            lec = new FileInputStream(origen);
            try (FileOutputStream esc = new FileOutputStream(copia)) {
                byte[] buffer = new byte[1024];
                int bytesLeidos;
                while((bytesLeidos = lec.read(buffer)) > 0){
                    System.out.print(bytesLeidos);
                    esc.write(buffer, 0, bytesLeidos);
                }
                
                //Cerramos los buffer//
                
                lec.close();
            }
        }   catch (FileNotFoundException ex) {
            java.util.logging.Logger.getLogger(Herramienta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(Herramienta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }
 

}
